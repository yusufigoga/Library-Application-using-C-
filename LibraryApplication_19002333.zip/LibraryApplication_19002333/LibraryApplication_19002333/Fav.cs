﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryApplication_19002333
{
    public partial class Fav : Form
    {
        public Fav()
        {
            InitializeComponent();
        }

        DataTable table = new DataTable();

        private void Fav_Load(object sender, EventArgs e)
        {
            
            //adding the colums in the data grid
            table.Columns.Add("Username", typeof(string));
            table.Columns.Add("Points", typeof(string));

            dataGridView1.DataSource = table;

            //calling the values from the textbox into the data grid
            string[] lines = File.ReadAllLines("Leaderbaord.txt");
            string[] values;

            for(int i =0; i <lines.Length; i++)
            {
                values = lines[i].ToString().Split(',');
                string[] row = new string[values.Length];

                for(int j = 0; j<values.Length; j++)
                {
                    row[j] = values[j].Trim();
                }

                table.Rows.Add(row);
            }

            //sorting the rows in the table by descending order according to player points
            dataGridView1.Sort(dataGridView1.Columns[1], ListSortDirection.Descending);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
