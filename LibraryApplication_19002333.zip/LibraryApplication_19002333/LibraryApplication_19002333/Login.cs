﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryApplication_19002333
{
    public partial class Login : Form
    {
        public static string name = "";
        
        public Login()
        {
            InitializeComponent();
            
        }

        private void bt1_Click(object sender, EventArgs e)
        {
            
            name = tb1.Text;
            //checking to see if there is text in the username box, if not show an error message
            if (tb1.Text == "")
            {
                MessageBox.Show("Please enter a Username");
            }
            else
            {
                //checking to see if the username already exists
                if (File.ReadAllText("Leaderbaord.txt").Contains(name))
                {
                    MessageBox.Show("This username already exists, choose a new username!");
                }
                //if everything checks out then move to the main activity
                else
                {
                    Menu ma = new Menu();
                    ma.Show();
                    this.Hide();
                }
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
