﻿namespace LibraryApplication_19002333
{
    partial class MainApplication
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainApplication));
            this.panelReplaceBooks = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.buttonEnter = new System.Windows.Forms.Button();
            this.btnReplace = new System.Windows.Forms.Button();
            this.panelReplaceBooks.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelReplaceBooks
            // 
            this.panelReplaceBooks.BackColor = System.Drawing.Color.Transparent;
            this.panelReplaceBooks.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelReplaceBooks.BackgroundImage")));
            this.panelReplaceBooks.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelReplaceBooks.Controls.Add(this.textBox1);
            this.panelReplaceBooks.Controls.Add(this.button6);
            this.panelReplaceBooks.Controls.Add(this.button3);
            this.panelReplaceBooks.Controls.Add(this.button2);
            this.panelReplaceBooks.Controls.Add(this.button1);
            this.panelReplaceBooks.Controls.Add(this.listBox1);
            this.panelReplaceBooks.Controls.Add(this.buttonEnter);
            this.panelReplaceBooks.Location = new System.Drawing.Point(32, 142);
            this.panelReplaceBooks.Margin = new System.Windows.Forms.Padding(4);
            this.panelReplaceBooks.Name = "panelReplaceBooks";
            this.panelReplaceBooks.Size = new System.Drawing.Size(588, 541);
            this.panelReplaceBooks.TabIndex = 11;
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("MV Boli", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(3, 4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(578, 28);
            this.textBox1.TabIndex = 27;
            this.textBox1.Text = "How to play : Arrange the numbers in the correct order, then press the enter butt" +
    "on";
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button6.Image = ((System.Drawing.Image)(resources.GetObject("button6.Image")));
            this.button6.Location = new System.Drawing.Point(19, 49);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(110, 111);
            this.button6.TabIndex = 26;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button5_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.Location = new System.Drawing.Point(19, 164);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(110, 111);
            this.button3.TabIndex = 24;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(441, 182);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(122, 112);
            this.button2.TabIndex = 23;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(441, 64);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(122, 112);
            this.button1.TabIndex = 22;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // listBox1
            // 
            this.listBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.listBox1.Font = new System.Drawing.Font("MV Boli", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.ForeColor = System.Drawing.Color.Gray;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 29;
            this.listBox1.Location = new System.Drawing.Point(183, 46);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(232, 323);
            this.listBox1.TabIndex = 21;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // buttonEnter
            // 
            this.buttonEnter.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.buttonEnter.Image = ((System.Drawing.Image)(resources.GetObject("buttonEnter.Image")));
            this.buttonEnter.Location = new System.Drawing.Point(224, 401);
            this.buttonEnter.Name = "buttonEnter";
            this.buttonEnter.Size = new System.Drawing.Size(149, 75);
            this.buttonEnter.TabIndex = 20;
            this.buttonEnter.UseVisualStyleBackColor = false;
            this.buttonEnter.Click += new System.EventHandler(this.buttonEnter_Click);
            // 
            // btnReplace
            // 
            this.btnReplace.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnReplace.BackgroundImage")));
            this.btnReplace.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnReplace.Font = new System.Drawing.Font("MV Boli", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReplace.Location = new System.Drawing.Point(38, 28);
            this.btnReplace.Margin = new System.Windows.Forms.Padding(4);
            this.btnReplace.Name = "btnReplace";
            this.btnReplace.Size = new System.Drawing.Size(183, 91);
            this.btnReplace.TabIndex = 8;
            this.btnReplace.Text = "Start";
            this.btnReplace.UseVisualStyleBackColor = true;
            this.btnReplace.Click += new System.EventHandler(this.btnReplace_Click);
            // 
            // MainApplication
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(645, 691);
            this.Controls.Add(this.panelReplaceBooks);
            this.Controls.Add(this.btnReplace);
            this.Name = "MainApplication";
            this.Text = "Westville Library";
            this.Load += new System.EventHandler(this.MainApplication_Load);
            this.panelReplaceBooks.ResumeLayout(false);
            this.panelReplaceBooks.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelReplaceBooks;
        private System.Windows.Forms.Button buttonEnter;
        private System.Windows.Forms.Button btnReplace;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox textBox1;
    }
}