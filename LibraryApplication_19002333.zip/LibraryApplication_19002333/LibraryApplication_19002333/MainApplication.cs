﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryApplication_19002333
{
    public partial class MainApplication : Form
    {
        //Declaration of Arrays and Variables
        double[] decNums = new double[10];
        string[] lets = new string[10];
        string callNums = "";
        string name;
        int count = 0;

        //Creating the list which stores the call numbers
        List<string> callNumbersList = new List<String>();
        
        public MainApplication()
        {
            //hiding all buttons and lists until button is clicked
            InitializeComponent();
            button1.Hide();
            button2.Hide();
            button3.Hide();
            button6.Hide();
            listBox1.Hide();
            buttonEnter.Hide();
            textBox1.Hide();
           
        }

        private void btnReplace_Click(object sender, EventArgs e)
        {
            //showing all buttons and lists when start button is clicked
           
            button3.Show();
            button6.Show();
            listBox1.Show();
            buttonEnter.Show();
            textBox1.Show();
            listBox1.Items.Clear();
            callNumbersList.Clear();
           

            // variables as place holders
            int firstNumbers;
            int secondNumbers;

            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

            System.Random ran = new System.Random();

            //Loop to populate the decimal Array as well as Letter array
            //All random values
            for (int i = 0; i < 10; i++)
            {
                firstNumbers = ran.Next(0, 999);
                secondNumbers = ran.Next(0, 99);
                double temp = (double)secondNumbers / 100;
                double temp2 = (double)firstNumbers + temp;
                decNums[i] = temp2;
                lets[i] = chars[ran.Next(0, 25)].ToString() + chars[ran.Next(0, 25)].ToString() + chars[ran.Next(0, 25)].ToString();

            }

            //creating the call numbers and adding them to the list
            for (int i = 0; i < 10; i++)
            {
                if (decNums[i] > -1 && decNums[i] < 10)
                {
                    callNums = "00" + decNums[i].ToString();

                }
                else if (decNums[i] > 9 && decNums[i] < 100)
                {
                    callNums = "0" + decNums[i].ToString();
                }
                else
                {
                    callNums = decNums[i].ToString();
                }

                //Add to the callNumbers list
                callNumbersList.Add(callNums + " " + lets[i]);
            }

            //adding the call numbers to the list
            listBox1.Items.Add(callNumbersList[0].ToString());
            listBox1.Items.Add(callNumbersList[1].ToString());
            listBox1.Items.Add(callNumbersList[2].ToString());
            listBox1.Items.Add(callNumbersList[3].ToString());
            listBox1.Items.Add(callNumbersList[4].ToString());
            listBox1.Items.Add(callNumbersList[5].ToString());
            listBox1.Items.Add(callNumbersList[6].ToString());
            listBox1.Items.Add(callNumbersList[7].ToString());
            listBox1.Items.Add(callNumbersList[8].ToString());
            listBox1.Items.Add(callNumbersList[9].ToString());

            btnReplace.Enabled = false;
        }

        private void MainApplication_Load(object sender, EventArgs e)
        {
            name = Login.name;
        }

        //this method allows values to move down in the list
        private void button2_Click(object sender, EventArgs e)
        {
            int index = listBox1.SelectedIndex;
            string listBoxItemText = listBox1.SelectedItem.ToString();
            if (index < listBox1.Items.Count-1)
            {
                listBox1.Items.RemoveAt(index);
                listBox1.Items.Insert(index + 1, listBoxItemText);
                listBox1.SetSelected(index + 1, true);
            }
        }

        //this method allows values to move down in the list
        private void button1_Click(object sender, EventArgs e)
        {
            int index = listBox1.SelectedIndex;
            string listBoxItemText = listBox1.SelectedItem.ToString();
            if(index>0)
            {
                listBox1.Items.RemoveAt(index);
                listBox1.Items.Insert(index-1, listBoxItemText);
                listBox1.SetSelected(index - 1, true);
            }
        }

        private void buttonEnter_Click(object sender, EventArgs e)
        {
            //sorting the sort number list in ascending order
            InsertionSort(decNums, lets);

            for (int i = 0; i < 10; i++)
            {
                if (decNums[i] > -1 && decNums[i] < 10)
                {
                    callNums = "00" + decNums[i].ToString();

                }
                else if (decNums[i] > 9 && decNums[i] < 100)
                {
                    callNums = "0" + decNums[i].ToString();
                }
                else
                {
                    callNums = decNums[i].ToString();
                }

                //Add to the callNumbers list
                callNumbersList[i] = callNums + " " + lets[i];
            }

            //creating a temporary list to hold the values that are in the listbox
            List<string> numList = new List<String>();
            foreach (object item in listBox1.Items)
            {
                numList.Add(item.ToString());
            }


            
            //checking to see if the items in the list box and the sorted items in the original list are matching
            if (numList.SequenceEqual(callNumbersList))
            {
                count = count + 1;
                
                string valu = name + "," + count;

               
                    using (StreamWriter w = File.AppendText("Leaderbaord.txt"))
                    {
                        w.WriteLine(valu);
                       
                    }

                    //if player is correct they will get a winner screen
                listBox1.Items.Clear();
                button1.Hide();
                button2.Hide();
                winner wi = new winner();
                wi.Show();
                


            }
            //if player is wrong they get a loser screen
            else
            {
                loser li = new loser();
                li.Show();
            }






        }

        //Insertion sort method  based on decimal numbers ascending order
        public static void InsertionSort(double[] decimalArray, string[] letsArray)
        {
            for (int i = 0; i < decimalArray.Length - 1; i++)
            {
                for (int j = i + 1; j > 0; j--)
                {
                    if (decimalArray[j - 1] > decimalArray[j])
                    {
                        double tempDecimal = decimalArray[j - 1];
                        decimalArray[j - 1] = decimalArray[j];
                        decimalArray[j] = tempDecimal;

                        string tempString = letsArray[j - 1];
                        letsArray[j - 1] = letsArray[j];
                        letsArray[j] = tempString;

                    }


                }
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //hiding buttons until item on listbox is clicked
            button1.Hide();
            button2.Hide();

            listBox1.Items.Clear();
            callNumbersList.Clear();
            // variables as place holders
            int firstNumbers;
            int secondNumbers;

            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

            System.Random ran = new System.Random();

            //Loop to populate the decimal Array as well as Letter array
            //All random values
            for (int i = 0; i < 10; i++)
            {
                firstNumbers = ran.Next(0, 999);
                secondNumbers = ran.Next(0, 99);
                double temp = (double)secondNumbers / 100;
                double temp2 = (double)firstNumbers + temp;
                decNums[i] = temp2;
                lets[i] = chars[ran.Next(0, 25)].ToString() + chars[ran.Next(0, 25)].ToString() + chars[ran.Next(0, 25)].ToString();

            }

            for (int i = 0; i < 10; i++)
            {
                if (decNums[i] > -1 && decNums[i] < 10)
                {
                    callNums = "00" + decNums[i].ToString();

                }
                else if (decNums[i] > 9 && decNums[i] < 100)
                {
                    callNums = "0" + decNums[i].ToString();
                }
                else
                {
                    callNums = decNums[i].ToString();
                }

                //Add to the callNumbers list
                callNumbersList.Add(callNums + " " + lets[i]);
            }

            listBox1.Items.Add(callNumbersList[0].ToString());
            listBox1.Items.Add(callNumbersList[1].ToString());
            listBox1.Items.Add(callNumbersList[2].ToString());
            listBox1.Items.Add(callNumbersList[3].ToString());
            listBox1.Items.Add(callNumbersList[4].ToString());
            listBox1.Items.Add(callNumbersList[5].ToString());
            listBox1.Items.Add(callNumbersList[6].ToString());
            listBox1.Items.Add(callNumbersList[7].ToString());
            listBox1.Items.Add(callNumbersList[8].ToString());
            listBox1.Items.Add(callNumbersList[9].ToString());

        }

        

        private void button5_Click(object sender, EventArgs e)
        {
            //takes you to the leaderbaord
            Fav fa = new Fav();
            fa.Show();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //showing the moving buttons only once we interact with the listview
            button1.Show();
            button2.Show();
        }
    }
}
