﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace LibraryApplication_19002333
{
    public partial class Menu : Form
    {
        //calling connection string from the class
        connection cn = new connection();

        string name;
        int count = 0;

        public Menu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //taking users to the replacing books screen
            MainApplication id = new MainApplication();
            id.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                //connecting to database
                SqlConnection con = cn.Con;
                //opening connection
                con.Open();
                //creating a query for easier use
                string query = "INSERT INTO login (Username, Points)  VALUES ('" + name + "', '" + count + "')";

                //reading the data
                SqlDataReader sdr = new SqlCommand(query, con).ExecuteReader();
                
                //closing connection
                con.Close();

            }
            //Exception handling
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            //Taking users to the identify areas screen
            IdentifyArea id = new IdentifyArea();
            id.Show();
            this.Hide();
        }

        private void Menu_Load(object sender, EventArgs e)
        {
            //calling the username from login page to add to the database
            name = Login.name;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //taking users to the replacing books screen
            FindCallNumbers fcn = new FindCallNumbers();
            fcn.Show();
            this.Hide();
        }
    }
}
