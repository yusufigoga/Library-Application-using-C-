﻿namespace LibraryApplication_19002333
{
    partial class FindCallNumbers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FindCallNumbers));
            this.panelReplaceBooks = new System.Windows.Forms.Panel();
            this.buttonEnter = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.panelReplaceBooks.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelReplaceBooks
            // 
            this.panelReplaceBooks.BackColor = System.Drawing.Color.Transparent;
            this.panelReplaceBooks.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelReplaceBooks.BackgroundImage")));
            this.panelReplaceBooks.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelReplaceBooks.Controls.Add(this.listBox1);
            this.panelReplaceBooks.Controls.Add(this.buttonEnter);
            this.panelReplaceBooks.Controls.Add(this.button6);
            this.panelReplaceBooks.Controls.Add(this.button3);
            this.panelReplaceBooks.Controls.Add(this.label2);
            this.panelReplaceBooks.Controls.Add(this.button1);
            this.panelReplaceBooks.Controls.Add(this.button2);
            this.panelReplaceBooks.Location = new System.Drawing.Point(55, 73);
            this.panelReplaceBooks.Margin = new System.Windows.Forms.Padding(4);
            this.panelReplaceBooks.Name = "panelReplaceBooks";
            this.panelReplaceBooks.Size = new System.Drawing.Size(791, 382);
            this.panelReplaceBooks.TabIndex = 29;
            // 
            // buttonEnter
            // 
            this.buttonEnter.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.buttonEnter.Image = ((System.Drawing.Image)(resources.GetObject("buttonEnter.Image")));
            this.buttonEnter.Location = new System.Drawing.Point(612, 251);
            this.buttonEnter.Name = "buttonEnter";
            this.buttonEnter.Size = new System.Drawing.Size(149, 75);
            this.buttonEnter.TabIndex = 26;
            this.buttonEnter.UseVisualStyleBackColor = false;
            this.buttonEnter.Click += new System.EventHandler(this.buttonEnter_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button6.Image = ((System.Drawing.Image)(resources.GetObject("button6.Image")));
            this.button6.Location = new System.Drawing.Point(25, 189);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(110, 111);
            this.button6.TabIndex = 27;
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.Location = new System.Drawing.Point(25, 72);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(110, 111);
            this.button3.TabIndex = 25;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MV Boli", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(234, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(347, 22);
            this.label2.TabIndex = 12;
            this.label2.Text = "Match the call numbers to the description";
            // 
            // listBox1
            // 
            this.listBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.listBox1.Font = new System.Drawing.Font("MV Boli", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.ForeColor = System.Drawing.Color.Gray;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 22;
            this.listBox1.Location = new System.Drawing.Point(169, 81);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(436, 224);
            this.listBox1.TabIndex = 28;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(612, 242);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(149, 75);
            this.button1.TabIndex = 29;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(612, 242);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(149, 75);
            this.button2.TabIndex = 30;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // FindCallNumbers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 529);
            this.Controls.Add(this.panelReplaceBooks);
            this.Name = "FindCallNumbers";
            this.Text = "Westville Library";
            this.Load += new System.EventHandler(this.FindCallNumbers_Load);
            this.panelReplaceBooks.ResumeLayout(false);
            this.panelReplaceBooks.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelReplaceBooks;
        private System.Windows.Forms.Button buttonEnter;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}