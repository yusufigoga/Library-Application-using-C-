﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;

namespace LibraryApplication_19002333
{
    public partial class FindCallNumbers : Form
    {
        string fileName = @"DeweyDecimalList.txt";
        string[] callNumbers = new string[10];
        string[] secondLevel = new string[41];
        List<string> termsList = new List<string>();
        List<string> termsList2 = new List<string>();

        string[] descriptionThirdLevelLst = new string[80];
        string[] callNumThirdLevelLst = new string[80];
        int index1 = 0;
        int index2 = 0;
        int index3 = 0;

        public string first;
        public string firsttemp;
        public string second;
        public string third;

       public string value;
       public bool value2;
        public string value3;
       

        public FindCallNumbers()
        {
            InitializeComponent();
        }


        private void FindCallNumbers_Load(object sender, EventArgs e)
        {
            using (StreamReader reader = new StreamReader(fileName))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {

                    if (line.Contains(">"))
                    {
                        string callNumThirdLevel = line.Substring(1, line.Length - 1);
                        callNumbers[index1] = callNumThirdLevel;
                        index1++;
                    }

                    if (line.Contains("-"))
                    {
                        string callNumThirdLevel = line.Substring(2, line.Length - 2);
                        secondLevel[index2] = callNumThirdLevel;
                        index2++;
                    }

                    if (line.Contains("*"))
                    {
                        string callNumThirdLevel = line.Substring(3, 3);
                        callNumThirdLevelLst[index3] = callNumThirdLevel;
                        string descripition = line.Substring(7, line.Length - 7);
                        descriptionThirdLevelLst[index3] = descripition;
                        index3++;
                    }


                }
            }

            Random rd = new Random();
            int randomIndex = rd.Next(0, 80);
            first = callNumThirdLevelLst[randomIndex];
            firsttemp = descriptionThirdLevelLst[randomIndex];
            second = first.Substring(0, 1);
            third= first.Substring(0, 2);

            MessageBox.Show(first);
            

            value = Array.Find(callNumbers, element => element.StartsWith(second));
            value3 = Array.Find(secondLevel, element => element.StartsWith(third));

            

            value2 = Array.Exists(secondLevel, element => element.StartsWith(second));

            //MessageBox.Show(value2.ToString());


            for (int i = 0; i < secondLevel.Length; ++i)
            {
                if (secondLevel[i].StartsWith(second))
                {
                    termsList.Add(secondLevel[i]);
                }
            }

            for (int i = 0; i < callNumThirdLevelLst.Length; ++i)
            {
                if (callNumThirdLevelLst[i].StartsWith(third))
                {
                    termsList2.Add(callNumThirdLevelLst[i]);
                }
            }


            for (int i = 0; i < 3; i++)
            {
                int start2 = rd.Next(0, callNumbers.Length);
                listBox1.Items.Add(callNumbers[start2]);
            }

            listBox1.Items.Add(value);

            button1.Hide();
            button2.Hide();


        }

        private void buttonEnter_Click(object sender, EventArgs e)
        {
            if(listBox1.SelectedItem == value)
            {
                listBox1.Items.Clear();

                for (int i = 0; i < 4; i++)
                {
                    listBox1.Items.Add(termsList[i]);
                }

                buttonEnter.Hide();
                button1.Show();
            }
            else
            {
                MessageBox.Show("Incorrect! Please select the correct value");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == value3)
            {
                listBox1.Items.Clear();

                for (int i = 0; i < 2; i++)
                {
                    listBox1.Items.Add(termsList2[i]);
                }

                button1.Hide();
                button2.Show();
                
            }
            else
            {
                MessageBox.Show("Incorrect! Please select the correct value");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == first)
            {
                listBox1.Items.Clear();

                for (int i = 0; i < 2; i++)
                {
                    //taking users to the replacing books screen
                    winner fn = new winner();
                    fn.Show();
                    
                }

                button2.Hide();

            }
            else
            {
                MessageBox.Show("Incorrect! Please select the correct value");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            buttonEnter.Show();
            listBox1.Items.Clear();

            Random rd = new Random();
            int randomIndex = rd.Next(0, 80);
            first = callNumThirdLevelLst[randomIndex];
            firsttemp = descriptionThirdLevelLst[randomIndex];
            second = first.Substring(0, 1);
            third = first.Substring(0, 2);

            MessageBox.Show(first);

            value = Array.Find(callNumbers, element => element.StartsWith(second));
            value3 = Array.Find(secondLevel, element => element.StartsWith(third));



            value2 = Array.Exists(secondLevel, element => element.StartsWith(second));

            MessageBox.Show(value.ToString());

            for (int i = 0; i < 3; i++)
            {
                int start2 = rd.Next(0, callNumbers.Length);
                listBox1.Items.Add(callNumbers[start2]);
            }

            listBox1.Items.Add(value);

            termsList.Clear();

            for (int i = 0; i < secondLevel.Length; ++i)
            {
                if (secondLevel[i].StartsWith(second))
                {
                    termsList.Add(secondLevel[i]);
                }
            }

            termsList2.Clear();
            for (int i = 0; i < callNumThirdLevelLst.Length; ++i)
            {
                if (callNumThirdLevelLst[i].StartsWith(third))
                {
                    termsList2.Add(callNumThirdLevelLst[i]);
                }
            }
        }
    }
}

