﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryApplication_19002333
{

    class connection
    {
        private SqlConnection con;

        public connection()
        {
             con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=" + Path.GetFullPath("DeweyDecimal.mdf").Replace(@"\bin\Debug", "") + "; Integrated Security=True;Connect Timeout=30");
        }

        public SqlConnection Con
        {
            get { return con; }
            set { con = value; }
        }
    }
    
}
