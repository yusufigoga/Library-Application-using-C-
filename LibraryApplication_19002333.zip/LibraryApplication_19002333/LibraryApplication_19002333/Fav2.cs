﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryApplication_19002333
{
    public partial class Fav2 : Form
    {
        //calling connection string from the class
        connection cn = new connection();
        
        public Fav2()
        {
            InitializeComponent();
        }

        DataTable table = new DataTable();

        private void Fav2_Load_1(object sender, EventArgs e)
        {
            //creating an sql connection and adding values to the datagridview

            try
            {
                SqlConnection con = cn.Con;
                con.Open();

                SqlDataAdapter da = new SqlDataAdapter("SELECT Username, Points FROM login WHERE Points >= 1 ORDER BY Points DESC", con);
                DataSet ds = new DataSet();
                da.Fill(ds, "login");
                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "login";

                con.Close();
            }

            catch(Exception ex)
            {
                MessageBox.Show("" + ex);
            }

            //sorting the rows in the table by descending order according to player points
            dataGridView1.Sort(dataGridView1.Columns[1], ListSortDirection.Descending);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        
    }
}
