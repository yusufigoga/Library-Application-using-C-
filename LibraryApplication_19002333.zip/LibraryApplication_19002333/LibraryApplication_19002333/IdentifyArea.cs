﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryApplication_19002333
{
    public partial class IdentifyArea : Form
    {
        //calling connection string from the class
        connection cn = new connection();

        //creating a dictionary to store call numbers and their descriptions 
        Dictionary<string, string> myDict = new Dictionary<string, string>();

        //creating a count to alternate the questions between call numbers and description
        public int count = 1;

        //creating all the global varaibles
        int countPoints = 0;
        string name;
        public string result1;
        public string result2;
        public string result3;
        public string result4;

        public IdentifyArea()
        {
            InitializeComponent();
        }

        private void IdentifyArea_Load(object sender, EventArgs e)
        {
            //calling the name from the login page
            name = Login.name;

            //list to store certain randamoised call numbers or descrption for the second column
            List<string> callNumbersList = new List<String>();

            // Adding key/value pairs to the dictionary
            myDict.Add("000", "General Knowledge");
            myDict.Add("100", "Philosophy & Psychology");
            myDict.Add("200", "Religion");
            myDict.Add("300", "Social Science");
            myDict.Add("400", "Languages");
            myDict.Add("500", "Science");
            myDict.Add("600", "Technology");
            myDict.Add("700", "Arts & Recreation");
            myDict.Add("800", "Literature");
            myDict.Add("900", "History & Geography");

            List<string> keyList = new List<string>(myDict.Keys);

            Random rand = new Random();

            //choosing a random call number from the dictonary and add it as a question

            string randomKey = keyList[rand.Next(keyList.Count)];
            string temp;

            textBox1.Text = randomKey;
            temp = myDict[randomKey];

            result1 = temp;

            //adding incorrect values to the answers
            string[] incorrectOne = { "Non-Fictional", "Fictional", "Politics"};
            int start = rand.Next(incorrectOne.Length);
            callNumbersList.Add(incorrectOne[start]);

            //comboBox1.Items.Add(temp);
            callNumbersList.Add(temp);

            //choosing a random call number from the dictonary and add it as a question

            string randomKey2 = keyList[rand.Next(keyList.Count)];
            string temp2;
            if (randomKey2 != randomKey)
            {
                textBox2.Text = randomKey2;
                temp2 = myDict[randomKey2];

               
                callNumbersList.Add(temp2);
                result2 = temp2;
            }
            else
            {
                string randomKey22 = keyList[rand.Next(keyList.Count)];
                string temp22;
                textBox2.Text = randomKey22;
                temp22 = myDict[randomKey22];

                
                callNumbersList.Add(temp22);

                result2 = temp22;

            }

            //adding incorrect values to the answers
            string[] incorrectTwo = { "Drama", "Cultural Studies", "Zoology" };
            int start2 = rand.Next(incorrectTwo.Length);
            callNumbersList.Add(incorrectTwo[start2]);

            //choosing a random call number from the dictonary and add it as a question

            string randomKey3 = keyList[rand.Next(keyList.Count)];
            string temp3;
            if (randomKey3 != randomKey & randomKey3 != randomKey2)
            {
                textBox3.Text = randomKey3;
                temp3 = myDict[randomKey3];

                
                callNumbersList.Add(temp3);
                result3 = temp3;
            }
            else
            {
                string randomKey33 = keyList[rand.Next(keyList.Count)];
                string temp33;
                textBox3.Text = randomKey33;
                temp33 = myDict[randomKey33];

                
                callNumbersList.Add(temp33);
                result3 = temp33;
            }

            //adding incorrect values to the answers
            string[] incorrectThree = { "Lifestyle", "Health and Medicine", "Criminality" };
            int start3 = rand.Next(incorrectThree.Length);
            callNumbersList.Add(incorrectThree[start3]);

            //choosing a random call number from the dictonary and add it as a question

            string randomKey4 = keyList[rand.Next(keyList.Count)];
              string temp4;

            if (randomKey4 != randomKey & randomKey4 != randomKey2 & randomKey4 != randomKey3)
            {
                textBox4.Text = randomKey4;
                temp4 = myDict[randomKey4];

                
                callNumbersList.Add(temp4);
                result4 = temp4;
            }
            else
            {
                string randomKey44 = keyList[rand.Next(keyList.Count)];
                string temp44;
                textBox4.Text = randomKey44;
                temp44 = myDict[randomKey44];

               
                callNumbersList.Add(temp44);
                result4 = temp44;
            }

            //shuffling the list for the answers

            var rnd = new Random();
            var randomized = callNumbersList.OrderBy(item => rnd.Next());

            foreach (var value in randomized)
            {
                comboBox1.Items.Add(value);
                comboBox2.Items.Add(value);
                comboBox3.Items.Add(value);
                comboBox4.Items.Add(value);
            }


            count--;
           

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            // removing the selected items from the comboboxes so they dont show when you reload questions
            comboBox1.Items.Remove(comboBox1.SelectedItem);
            comboBox2.Items.Remove(comboBox2.SelectedItem);
            comboBox3.Items.Remove(comboBox3.SelectedItem);
            comboBox4.Items.Remove(comboBox4.SelectedItem);

            //if the count = 0 then descrpiption shows as the question 
            if (count == 0)
            {
                //clearing comboboxes and textboxes 
                label2.Text = "Match the description to the call numbers";
                comboBox1.Items.Clear();
                comboBox2.Items.Clear();
                comboBox3.Items.Clear();
                comboBox4.Items.Clear();

                //hiding comboboxes and textboxes 
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();

                comboBox1.Show();
                comboBox2.Show();
                comboBox3.Show();
                comboBox4.Show();

                textBox1.Show();
                textBox2.Show();
                textBox3.Show();
                textBox4.Show();

                buttonEnter.Show();

                List<string> callNumbersList = new List<String>();

                List<string> keyList = new List<string>(myDict.Keys);

                Random rand = new Random();

                //choosing a random call number from the dictonary and add it as a question
                string randomKey = keyList[rand.Next(keyList.Count)];
                string temp;

                
                temp = myDict[randomKey];
                textBox1.Text = temp;

                //adding incorrect values to the answers
                string[] incorrectOne = { "150", "750", "850" };
                int start = rand.Next(incorrectOne.Length);
                callNumbersList.Add(incorrectOne[start]);

                //comboBox1.Items.Add(temp);
                callNumbersList.Add(randomKey);
                result1 = randomKey;

                //choosing a random call number from the dictonary and add it as a question
                string randomKey2 = keyList[rand.Next(keyList.Count)];
                string temp2;
                temp2 = myDict[randomKey2];

                if (temp2 != temp)
                {
                    textBox2.Text = temp2;
                    callNumbersList.Add(randomKey2);
                    result2 = randomKey2;
                }
                else
                {
                    string randomKey22 = keyList[rand.Next(keyList.Count)];
                    string temp22;
                   
                    temp22 = myDict[randomKey22];

                    textBox2.Text = temp22;
                    callNumbersList.Add(randomKey22);
                    result2 = randomKey22;

                }

                //adding incorrect values to the answers
                string[] incorrectTwo = { "250", "450", "950" };
                int start2 = rand.Next(incorrectTwo.Length);
                callNumbersList.Add(incorrectTwo[start2]);

                //choosing a random call number from the dictonary and add it as a question
                string randomKey3 = keyList[rand.Next(keyList.Count)];
                string temp3;
                temp3 = myDict[randomKey3];

                if (temp3 != temp & temp3 != temp2)
                {
                    textBox3.Text = temp3;
                    callNumbersList.Add(randomKey3);
                    result3 = randomKey3;
                }
                else
                {
                    string randomKey33 = keyList[rand.Next(keyList.Count)];
                    string temp33;

                    temp33 = myDict[randomKey33];

                    textBox3.Text = temp33;
                    callNumbersList.Add(randomKey33);
                    result3 = randomKey33;

                }

                //adding incorrect values to the answers
                string[] incorrectThree = { "350", "550", "650" };
                int start3 = rand.Next(incorrectThree.Length);
                callNumbersList.Add(incorrectThree[start3]);

                //choosing a random call number from the dictonary and add it as a question
                string randomKey4 = keyList[rand.Next(keyList.Count)];
                string temp4;
                temp4 = myDict[randomKey4];

                if (temp4 != temp & temp4 != temp2 & temp4 != temp3)
                {
                    textBox4.Text = temp4;
                    callNumbersList.Add(randomKey4);
                    result4 = randomKey4;
                }
                else
                {
                    string randomKey44 = keyList[rand.Next(keyList.Count)];
                    string temp44;

                    temp44 = myDict[randomKey44];

                    textBox4.Text = temp44;
                    callNumbersList.Add(randomKey44);
                    result4 = randomKey44;

                }

                //shuffling the answers 
                var rnd = new Random();
                var randomized = callNumbersList.OrderBy(item => rnd.Next());

                foreach (var value in randomized)
                {
                    comboBox1.Items.Add(value);
                    comboBox2.Items.Add(value);
                    comboBox3.Items.Add(value);
                    comboBox4.Items.Add(value);
                }

                count++;
            }

            else if(count ==1)
            {
                //showing the comboboxes for new reloaded values
                comboBox1.Show();
                comboBox2.Show();
                comboBox3.Show();
                comboBox4.Show();

                textBox1.Show();
                textBox2.Show();
                textBox3.Show();
                textBox4.Show();

                buttonEnter.Show();

                label2.Text = "Match the call numbers to the description";

                //clearing the comboboxes for new reloaded values
                comboBox1.Items.Clear();
                comboBox2.Items.Clear();
                comboBox3.Items.Clear();
                comboBox4.Items.Clear();

                List<string> callNumbersList = new List<String>();

                List<string> keyList = new List<string>(myDict.Keys);

                Random rand = new Random();

                //choosing a random call number from the dictonary and add it as a question
                string randomKey = keyList[rand.Next(keyList.Count)];
                string temp;

                textBox1.Text = randomKey;
                temp = myDict[randomKey];

                //adding incorrect values to the answers
                string[] incorrectOne = { "Non-Fictional", "Fictional", "Politics" };
                int start = rand.Next(incorrectOne.Length);
                callNumbersList.Add(incorrectOne[start]);

                //choosing a random call number from the dictonary and add it as a question
                callNumbersList.Add(temp);
                result1 = temp;

                string randomKey2 = keyList[rand.Next(keyList.Count)];
                string temp2;
                if (randomKey2 != randomKey)
                {
                    textBox2.Text = randomKey2;
                    temp2 = myDict[randomKey2];

                    //comboBox2.Text = temp2;
                    callNumbersList.Add(temp2);
                    result2 = temp2;
                }
                else
                {
                    string randomKey22 = keyList[rand.Next(keyList.Count)];
                    string temp22;
                    textBox2.Text = randomKey22;
                    temp22 = myDict[randomKey22];

                    //comboBox2.Text = temp22;
                    callNumbersList.Add(temp22);
                    result2 = temp22;

                }

                //adding incorrect values to the answers
                string[] incorrectTwo = { "Drama", "Cultural Studies", "Zoology" };
                int start2 = rand.Next(incorrectTwo.Length);
                callNumbersList.Add(incorrectTwo[start2]);

                //choosing a random call number from the dictonary and add it as a question
                string randomKey3 = keyList[rand.Next(keyList.Count)];
                string temp3;
                if (randomKey3 != randomKey & randomKey3 != randomKey2)
                {
                    textBox3.Text = randomKey3;
                    temp3 = myDict[randomKey3];

                    //comboBox3.Text = temp3;
                    callNumbersList.Add(temp3);
                    result3 = temp3;
                }
                else
                {
                    string randomKey33 = keyList[rand.Next(keyList.Count)];
                    string temp33;
                    textBox3.Text = randomKey33;
                    temp33 = myDict[randomKey33];

                    //comboBox3.Text = temp33;
                    callNumbersList.Add(temp33);
                    result3 = temp33;
                }

                //adding incorrect values to the answers
                string[] incorrectThree = { "Lifestyle", "Health and Medicine", "Criminality" };
                int start3 = rand.Next(incorrectThree.Length);
                callNumbersList.Add(incorrectThree[start3]);

                //choosing a random call number from the dictonary and add it as a question
                string randomKey4 = keyList[rand.Next(keyList.Count)];
                string temp4;

                if (randomKey4 != randomKey & randomKey4 != randomKey2 & randomKey4 != randomKey3)
                {
                    textBox4.Text = randomKey4;
                    temp4 = myDict[randomKey4];

                    //comboBox4.Text = temp4;
                    callNumbersList.Add(temp4);
                    result4 = temp4;
                }
                else
                {
                    string randomKey44 = keyList[rand.Next(keyList.Count)];
                    string temp44;
                    textBox4.Text = randomKey44;
                    temp44 = myDict[randomKey44];

                    //comboBox3.Text = temp33;
                    callNumbersList.Add(temp44);
                    result4 = temp44;
                }

                //shuffling the answers 
                var rnd = new Random();
                var randomized = callNumbersList.OrderBy(item => rnd.Next());

                foreach (var value in randomized)
                {
                    comboBox1.Items.Add(value);
                    comboBox2.Items.Add(value);
                    comboBox3.Items.Add(value);
                    comboBox4.Items.Add(value);
                }

                count--;
            }
        }

        private void buttonEnter_Click(object sender, EventArgs e)
        {
            //checking to see if all answers have been answered
            if (comboBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Please select all answers before submitting!");
            }
            else if(comboBox2.SelectedIndex == -1)
            {
                MessageBox.Show("Please select all answers before submitting!");
            }
            else if(comboBox3.SelectedIndex == -1)
            {
                MessageBox.Show("Please select all answers before submitting!");
            }
            else if(comboBox4.SelectedIndex == -1)
            {
                MessageBox.Show("Please select all answers before submitting!");
            }
            else
            {
                //checking to see if the answers are correct
                string cm1 = comboBox1.SelectedItem.ToString();
                string cm2 = comboBox2.SelectedItem.ToString();
                string cm3 = comboBox3.SelectedItem.ToString();
                string cm4 = comboBox4.SelectedItem.ToString();

                if (cm1 == result1 & cm2 == result2 & cm3 == result3 & cm4 == result4)
                {
                    countPoints = countPoints + 1;

                    string valu = name + "," + countPoints;


                    using (StreamWriter w = File.AppendText("LeaderbaordTwo.txt"))
                    {
                        w.WriteLine(valu);

                    }

                    SqlConnection con = cn.Con;
                    //opening the connection
                    con.Open();

                    //updating the login table
                    string query = "UPDATE login SET Points =  '" + countPoints + "'  WHERE Username = '" + name + "'";
                    //reading the query from the database
                    SqlDataReader sdf = new SqlCommand(query, con).ExecuteReader();

                    con.Close();

                    //hiding the comboboxes and textboxes if they are successful
                    comboBox1.Hide();
                    comboBox2.Hide();
                    comboBox3.Hide();
                    comboBox4.Hide();

                    textBox1.Hide();
                    textBox2.Hide();
                    textBox3.Hide();
                    textBox4.Hide();

                    buttonEnter.Hide();

                    //if player wins take them to winner screen
                    winner winner = new winner();
                    winner.Show();
                    
                }
                else
                {
                    //if player loses take them to loser screen
                    loser loser = new loser();
                    loser.Show();
                    
                }
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            //takes you to the leaderbaord for identfying areas
            Fav2 fa = new Fav2();
            fa.Show();
        }
    }
}
